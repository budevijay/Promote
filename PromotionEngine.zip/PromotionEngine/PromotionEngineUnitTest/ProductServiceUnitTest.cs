﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using PromotionEngine;

namespace PromotionEngineUnitTest
{
    [TestClass]
    public class ProductServiceUnitTest
    {
        private Mock<ProductService> mockProductService = null;

       
        [TestMethod]
        [TestCategory("Unit")]

        public void GetPriceByType_Test()
        {
            mockProductService = new Mock<ProductService>();

           var resultA = mockProductService.Object.GetPriceByType("A");
            var resultB = mockProductService.Object.GetPriceByType("B");
            var resultC = mockProductService.Object.GetPriceByType("C");
            var resultD = mockProductService.Object.GetPriceByType("D");
            Assert.AreEqual(50, resultA);
            Assert.AreEqual(30, resultB);
            Assert.AreEqual(20, resultC);
            Assert.AreEqual(15, resultD);
        }

        [TestMethod]
        [TestCategory("Unit")]
        public void GetTotalPrice_Test()
        {
            mockProductService = new Mock<ProductService>();
            Product ProductA = new Product();
            ProductA.sukChar = "A";
            Product ProductB = new Product();
            ProductB.sukChar = "B";
            Product ProductC = new Product();
            ProductC.sukChar = "C";
            Product ProductD = new Product();
            ProductD.sukChar = "D";

            var list1 = new List<Product>();
            list1.Add(ProductA);
            list1.Add(ProductA);
            list1.Add(ProductA);
            var resultA = mockProductService.Object.GetTotalPrice(list1);
            list1.Clear();

            list1 = new List<Product>();
            list1.Add(ProductB);
            list1.Add(ProductB);
            var resultB = mockProductService.Object.GetTotalPrice(list1);
            list1.Clear();

            list1 = new List<Product>();
            list1.Add(ProductC);
            list1.Add(ProductD);    
            var resultCD = mockProductService.Object.GetTotalPrice(list1);
            list1.Clear();

            list1 = new List<Product>();
            list1.Add(ProductC);
            list1.Add(ProductD);
            list1.Add(ProductA);
            list1.Add(ProductB);
            var result = mockProductService.Object.GetTotalPrice(list1);

            Assert.AreEqual(130, resultA);
            Assert.AreEqual(45, resultB);
            Assert.AreEqual(30, resultCD);
            Assert.AreEqual(110, result);
        }


    }
}
