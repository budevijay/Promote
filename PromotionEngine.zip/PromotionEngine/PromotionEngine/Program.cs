﻿using System;
using System.Collections.Generic;

namespace PromotionEngine
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Product> products = new List<Product>();
            ProductService service = new ProductService();
            Console.WriteLine("Enter number of SUK to Add- Integer only");

            int suk = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < suk; i++)
            {
                Console.WriteLine("enter the type of product:A,B,C or D");
                string sukChar = Console.ReadLine();
                Product objProduct = new Product();
                objProduct.sukChar = sukChar.ToUpper();
                products.Add(objProduct);
            }

            decimal promoprice = service.GetTotalPrice(products);


            Console.WriteLine($" Price: {promoprice.ToString("0.00")}");
            Console.WriteLine("");
            Console.ReadLine();
        }
    }
}
