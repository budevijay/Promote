﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PromotionEngine
{
    public class Rules
    {
        public int RuleID { get; set; }
        public Dictionary<string, int> RuleInfo { get; set; }
        public decimal PromoPrice { get; set; }

        public Rules(int _ruleID, Dictionary<string, int> _ruleInfo, decimal _rulePrice)
        {
            this.RuleID = _ruleID;
            this.RuleInfo = _ruleInfo;
            this.PromoPrice = _rulePrice;
        }

    }
}
