﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PromotionEngine
{
    public class Product
    {
        public string sukChar { get; set; }
        public decimal sukUnitPrice { get; set; }

    }
}
