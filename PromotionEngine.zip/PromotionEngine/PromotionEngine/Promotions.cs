﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PromotionEngine
{
    static class Promotions
    {
        public static List<Rules> GetPromotions()
        {

            Dictionary<String, int> rule5 = new Dictionary<String, int>();
            rule5.Add("A", 3);
            Dictionary<String, int> rule6 = new Dictionary<String, int>();
            rule6.Add("B", 2);
            Dictionary<String, int> rule7 = new Dictionary<String, int>();
            rule7.Add("C", 1);
            rule7.Add("D", 1);


            List<Rules> promotions = new List<Rules>()
            {
                new Rules(1, rule5, 130),
                new Rules(2, rule6, 45),
                new Rules(3, rule7, 30)
            };
            return promotions;
        }
    }
}
