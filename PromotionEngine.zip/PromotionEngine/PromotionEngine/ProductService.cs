﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PromotionEngine
{
    public class ProductService : IProductService
    {
        public decimal GetPriceByType(string sukChar)
        {
            decimal sukUnitPrice = 0m;
            switch (sukChar)
            {
                case "A":
                    sukUnitPrice = 50;

                    break;
                case "B":
                    sukUnitPrice = 30;

                    break;
                case "C":
                    sukUnitPrice = 20;

                    break;
                case "D":
                    sukUnitPrice = 15;
                    break;
                default:
                    sukUnitPrice = 0;
                    break;
            }
            return sukUnitPrice;
        }

        public decimal GetTotalPrice(List<Product> products)
        {
            int countA = 0;
            int countB = 0;
            int countC = 0;
            int countD = 0;

            decimal totalPriceA = 0m;
            decimal totalPriceB = 0m;
            decimal totalPriceC = 0m;
            decimal totalPriceD = 0m;
            decimal totalPriceCD = 0m;

            var g = products.GroupBy(i => i.sukChar);

            foreach (var grp in g)
            {
                switch (grp.Key)
                {
                    case "A":
                        countA = grp.Count();
                        break;
                    case "B":
                        countB = grp.Count();
                        break;
                    case "C":
                        countC = grp.Count();
                        break;
                    case "D":
                        countD = grp.Count();
                        break;
                }
            }
            if (countA > 0)
            {
                totalPriceA = ((countA / 3) * GetPromotion("A")) + ((countA % 3) * GetPriceByType("A"));
            }
            if (countB > 0)
            {
                totalPriceB = ((countB / 2) * GetPromotion("B")) + ((countB % 2) * GetPriceByType("B"));
            }
            if (countC == countD && countC > 0)
            {
                totalPriceCD = countC * 30;
            }
            else if (countC < countD)
            {
                totalPriceCD = countC * 30;
                totalPriceD = (countD - countC) * GetPriceByType("D");
            }
            else if (countC > countD)
            {
                totalPriceCD = countD * 30;
                totalPriceC = (countC - countD) * GetPriceByType("C");
            }
            return totalPriceA + totalPriceB + totalPriceC + totalPriceD + totalPriceCD;
        }

        private decimal GetPromotion(string keyValue)
        {
            var result = Promotions.GetPromotions()
                            .Where(rule => rule.RuleInfo.Any(y => keyValue == y.Key))
                            .Select(rule => rule.PromoPrice).ToList();

            return result.Sum();
        }



    }
}
